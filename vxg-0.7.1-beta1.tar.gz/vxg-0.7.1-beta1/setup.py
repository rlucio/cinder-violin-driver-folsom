from distutils.core import setup

# Get the version from version.py
try:
    f = open("vxg/version.py")
    for line in f:
        if line.startswith("__version__"):
            # First strip whitespace then quotes
            pkg_vers = line.split("=")[1].strip().strip(' "\'')
            break

    f.close()

except:
    pkg_vers = "unknown"

setup(name         = 'vxg',
      version      = pkg_vers,
      description  = 'Violin Memory XML Interface Library',
      author       = 'Violin Memory',
      author_email = 'support@vmem.com',
      url          = 'http://www.vmem.com',
      license      = 'BSD',
      packages     = ['vxg', 'vxg.core', 'vxg.vshare', 'vxg.varray'],
      requires     = ['xml.dom', 'xml.etree', 'urllib', 'urllib2', 'inspect'],
      )

