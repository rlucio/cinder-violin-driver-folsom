#!/usr/bin/env python

# =============================================================================
# Copyright 2012-2013 Violin Memory, Inc.. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# Redistributions of source code must retain the above copyright notice, this
# list of conditions and the following disclaimer.
#
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY VIOLIN MEMORY, INC  ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
# EVENT SHALL VIOLIN MEMORY, INC  OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
# OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are
# those of the authors and should not be interpreted as representing official
# policies, either expressed or implied, of Violin Memory, Inc.
# =============================================================================

from vxg.core.node import XGNode
from vxg.core.error import *
from vxg.core.request import XGQuery, XGAction, XGEvent, XGSet

"""
Here's an example of how to extend the functionality in this module:

class ISCSIManager_1(ISCSIManager):
    def __init__(self, basic):
        super(ISCSIManager_1, self).__init__(basic)

    def new_function(self, *args):
        pass

"""

class ISCSIManager(object):
    def __init__(self, basic):
        self._basic = basic

    def enable_iscsi_locally(self):
        """
        Enable local node iSCSI.

        Returns:
            Action result as a dict.

        """
        return self._iscsi_local(True)

    def disable_iscsi_locally(self):
        """
        Disable local node iSCSI.

        Returns:
            Action result as a dict.

        """
        return self._iscsi_local(False)

    def enable_iscsi_globally(self):
        """
        Enable iSCSI for all nodes.

        Returns:
            Action result as a dict.

        """
        return self._iscsi_global(True)

    def disable_iscsi_globally(self):
        """
        Disable iSCSI for all nodes.

        Returns:
            Action result as a dict.

        """
        return self._iscsi_global(False)

    def create_iscsi_target(self, target):
        """
        Create an iSCSI target.

        Arguments:
            target -- string

        Returns:
            Action result as a dict.

        """
        return self._iscsi_target_create(target, True)

    def delete_iscsi_target(self, target):
        """
        Deletes an iSCSI target.

        Arguments:
            target -- string

        Returns:
            Action result as a dict.

        """
        return self._iscsi_target_create(target, False)

    def bind_ip_to_target(self, target, ip):
        """
        Binds an IP to an iSCSI target.

        Arguments:
            target -- string
            ip     -- string (string or list)

        Returns:
            Action result as a dict.

        """
        return self._iscsi_target_bind(target, ip, True)

    def unbind_ip_from_target(self, target, ip):
        """
        Unbinds an IP from an iSCSI target.

        Arguments:
            target -- string
            ip     -- string (string or list)

        Returns:
            Action result as a dict.

        """
        return self._iscsi_target_bind(target, ip, False)


    # Begin internal functions

    def _iscsi_local(self, enable):
        """
        Internal work function for:
            enable_iscsi_locally
            disable_iscsi_locally

        """
        nodes = []
        nodes.append(XGNode('enable', 'bool', enable))

        return self._basic.perform_action('/vshare/actions' +
                                          '/iscsi/enable_local', nodes)

    def _iscsi_global(self, enable):
        """
        Internal work function for:
            enable_iscsi_globally
            disable_iscsi_globally

        """
        nodes = []
        nodes.append(XGNode('enable', 'bool', enable))

        return self._basic.perform_action('/vshare/actions' +
                                          '/iscsi/enable_global', nodes)

    def _iscsi_target_create(self, target, create):
        """
        Internal work function for:
            create_iscsi_target
            delete_iscsi_target

        """
        nodes = []
        nodes.append(XGNode('target', 'string', target))
        nodes.append(XGNode('create', 'bool', create))

        return self._basic.perform_action('/vshare/actions' +
                                          '/iscsi/target/create', nodes)

    def _iscsi_target_bind(self, target, ip, add):
        """
        Internal work function for:
            bind_ip_to_target
            unbind_ip_from_target

        """
        nodes = []
        nodes.append(XGNode('target', 'string', target))
        nodes.extend(XGNode.as_node_list('ip/{0}', 'string', ip))
        nodes.append(XGNode('add', 'bool', add))

        return self._basic.perform_action('/vshare/actions' +
                                          '/iscsi/target/bind', nodes)



